Suggested Test Directory

We recommend that you place your testing code in this directory. This way, IDEs
like IntelliJ will recognize the files as tests. Using the same package name as
the main code allows your testing code to access certain non-public methods and
classes within your implementation.
